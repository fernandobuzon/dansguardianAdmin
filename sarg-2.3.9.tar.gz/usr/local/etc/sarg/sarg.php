<?php

function rglob($pattern, $flags = 0) {
    $files = glob($pattern, $flags); 
    foreach (glob(dirname($pattern).'/*', GLOB_ONLYDIR|GLOB_NOSORT) as $dir) {
        $files = array_merge($files, rglob($dir.'/'.basename($pattern), $flags));
    }
    return $files;
}

system("/usr/local/bin/sarg > /dev/null 2>&1");
system("cp /usr/local/etc/sarg/logo.png /usr/local/www/sarg/images/sarg.png");

$files = rglob('/usr/local/www/sarg/*.html');
foreach ($files as $file)
{
  system("sed -i '' 's/http:\/\/sarg.sourceforge.net/http:\/\/www.multcorp.com.br/' $file");
  system("sed -i '' 's/SARG, Squid Analysis Report Generator. Logo by Osamu Matsuzaki//' $file");
  system("sed -i '' 's/&nbsp;Squid Analysis Report Generator//' $file");
  system("sed -i '' '1s/^/\<\?php require_once\(\"\/etc\/inc\/authgui.inc\"\)\; \?\>/' $file");
  system("sed -i '' 's/http:\/\/sarg.sourceforge.net/http:\/\/www.multcorp.com.br/' $file");
  system("sed -i '' 's/sarg-2.3.9 Sep-21-2014/MultCorp/' $file");
  system("sed -i '' 's/\\.html/\\.php/g' $file");

  $file = str_replace(array("\n", "\r"), '', $file);
  $php = str_replace('.html', '.php', $file);
  system("mv $file $php");
}

?>
